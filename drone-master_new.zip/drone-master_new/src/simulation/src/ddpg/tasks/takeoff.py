import numpy as np
from simulation.msg import float32array
from std_msgs.msg import Float32

import gym
from gym import error, spaces, utils
from gym.utils import seeding

class MyTask(gym.Env):
    metadata = {'render.modes': ['human']}

    def __init__(self):
        
        space_size = 300.0   # max size of environment
        max_speed = 60.0   # max speed of each joint
        
        # initialization observation space and action space
        self.observation_space = spaces.Box(
                np.array([-space_size/2, 0.0, -space_size/2]),
                np.array([space_size/2, space_size, space_size/2]))

        self.action_space = spaces.Box(
                np.array([0]),
                np.array([max_speed]))

        self.action_size = 1
        self.state_size = 3
        #print("Takeoff(): observation_space = {}".format(self.observation_space))
        #print("Takeoff(): action_space = {}".format(self.action_space))
        
        # Task-specific parameters
        self.max_duration = 15           # secs
        self.target_z = 10.0             # meters
        #self.last_state = np.array([0,0,0])
        #self.last_action = np.array([0.0])
        self.last_timestamp = 0

    def reset(self):
        # reset the position and speed
        #self.last_state = np.array([0,0,0])
        #self.last_action = np.array([0.0])
        self.last_timestamp = 0

    def update(self, timestamp, pose):
        state = np.array([pose[0], pose[1], pose[2]])
        done = False
        
        if timestamp > self.max_duration:
            done = True

        action = self.agent.act(state)
        action_ = (self.action_space.high - self.action_space.low)*(action+1)/2 + self.action_space.low

        reward = self.get_reward(timestamp, pose, action_)
        print("pos: {}".format(pose))
        print("current reward: {}".format(reward))
       
        self.next_height = pose[1] + action_[0] * (timestamp - self.last_timestamp)
        self.next_state = np.array([pose[0], self.next_height, pose[2]])
        self.agent.step(state,action_, reward, self.next_state, done)
        
        self.last_timestamp = timestamp
       # self.last_state = state
       # self.last_action = action_
       # self.float_action = float32array(action_[0], action_[1], action_[2])

        if action is not None:
        
            return action_, done
        else:
            return None, done


    def get_reward(self, timestamp, pose, action):
        """get reward"""        
        reward = -min(abs(self.target_z - pose[1]), 20.0)
        
        if pose[1] >= self.target_z <= 15:
            reward += 5.0 + (self.max_duration - timestamp) - 2*( pose[1] - self.target_z)
        if pose [1] == self.target_z:
            reward += 10
        
        if pose[1] > 15:
            reward -= 20
        return reward

    def set_agent(self, agent):
        """Set an agent to carry out this task; to be called from update."""
        self.agent = agent


