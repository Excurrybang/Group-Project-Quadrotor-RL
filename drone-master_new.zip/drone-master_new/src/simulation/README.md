## Simulation instructions

- Press "play" in Unity
- `roslaunch process_manager process_manager.launch`
- `cd fla-gtsc/fla_root/groundsation && ./runfms.sh 127.0.0.1`
- `roslaunch simulation mission.launch`


Link to Unity for Linux:
http://download.unity3d.com/download_unity/linux/unity-editor-5.4.0p1+20160810_amd64.deb

Link to Unity Sim Project:
https://www.dropbox.com/s/5jpb6f77dma9t0z/2017-04-14_Building_77.tar.gz?dl=0
